import React, {
  useEffect,
  useRef,
  useState,
  useContext,
  createContext,
} from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  BookOpen,
  ShoppingCart,
  Clock,
  ShieldCheck,
  Star,
  TrendingUp,
  Activity,
  Award,
  BarChart3,
  Info,
  Check,
  XCircle,
  Calendar,
} from "lucide-react";

/* ================== UI PRIMITIVES ================== */
export const Button = ({ className = "", asChild, children, ...p }) => {
  const isOutline = className.includes("outline");
  const base =
    "inline-flex items-center justify-center px-4 py-2 text-sm font-medium transition-transform duration-150 hover:-translate-y-0.5 hover:scale-[1.01] rounded-2xl " +
    (isOutline ? "border border-subtle" : "accent-btn") +
    (className ? " " + className : "");
  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      className: `${base} ${children.props?.className || ""}`.trim(),
      ...p,
    });
  }
  return (
    <button className={base} {...p}>
      {children}
    </button>
  );
};
export const Card = ({ className = "", children, ...p }) => (
  <div
    className={`rounded-2xl border border-subtle bg-card transition-all duration-200 ${className}`}
    {...p}
  >
    {children}
  </div>
);
export const CardHeader = ({ className = "", children, ...p }) => (
  <div className={`p-6 border-b border-subtle ${className}`} {...p}>
    {children}
  </div>
);
export const CardTitle = ({ className = "", children, ...p }) => (
  <div className={`text-lg font-semibold ${className}`} {...p}>
    {children}
  </div>
);
export const CardContent = ({ className = "", children, ...p }) => (
  <div className={`p-6 ${className}`} {...p}>
    {children}
  </div>
);

/* ================== ACCORDION ================== */
const AccordionItemCtx = createContext(null);
export const Accordion = ({ children }) => <div>{children}</div>;
export const AccordionItem = ({ defaultOpen = false, children }) => {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <AccordionItemCtx.Provider value={{ open, setOpen }}>
      <div className="border-b border-subtle">{children}</div>
    </AccordionItemCtx.Provider>
  );
};
export const AccordionTrigger = ({ children }) => {
  const ctx = useContext(AccordionItemCtx);
  if (!ctx) return null;
  const { open, setOpen } = ctx;
  return (
    <button
      type="button"
      className="w-full text-left cursor-pointer p-4 font-medium flex items-center justify-between"
      onClick={() => setOpen(!open)}
      aria-expanded={open}
    >
      <span>{children}</span>
      <span className="text-neutral-500">{open ? "–" : "+"}</span>
    </button>
  );
};
export const AccordionContent = ({ children }) => {
  const ctx = useContext(AccordionItemCtx);
  if (!ctx) return null;
  const { open } = ctx;
  return (
    <div
      className="overflow-hidden transition-all duration-300"
      style={{ maxHeight: open ? "1000px" : "0px", opacity: open ? 1 : 0 }}
      aria-hidden={!open}
    >
      <div className="p-4 text-sm text-neutral-400">{children}</div>
    </div>
  );
};

/* ================== LAYOUT & THEME ================== */
/* Gardé générique, mais on n'utilise plus withConstellations dans les sections du dessous */
const Section = ({
  id,
  title,
  kicker,
  children,
  withConstellations = false,
  constSize = "sm", // "sm" | "md" | "xl"
}) => (
  <section id={id} className="scroll-mt-24 py-16 md:py-24">
    <div className="mx-auto max-w-6xl px-4">
      <div className={withConstellations ? "constellation-wrap" : ""}>
        {withConstellations && (
          <ConstellationCanvas
            className={`constellation-strip constellation-strip--${constSize}`}
          />
        )}
        <div className={withConstellations ? "constellation-content" : ""}>
          <div className="mb-8">
            {kicker && (
              <p className="mb-2 text-sm uppercase tracking-widest text-muted-foreground">
                {kicker}
              </p>
            )}
            {title && (
              <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
                {title}
              </h2>
            )}
          </div>
          {children}
        </div>
      </div>
    </div>
  </section>
);

const GlobalThemeStyles = () => (
  <style>{`
    :root{
      --background: 0 0% 0%;
      --foreground: 210 20% 98%;
      --muted-foreground: 215 16% 70%;
      --card: 0 0% 6%;
      --border: 0 0% 12%;
      --accent: 28 95% 55%; /* ORANGE */
    }
    html { scroll-behavior: smooth; }
    body{
      margin:0;
      font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Inter, sans-serif;
      background-color: hsl(var(--background));
      color: hsl(var(--foreground));
    }
    .text-muted-foreground{ color: hsl(var(--muted-foreground)); }
    .bg-card{ background-color: hsl(var(--card)); }
    .border-subtle{ border-color: hsl(var(--border)); }
    .accent-btn{ background-color: hsl(var(--accent)); color: #1a1a1a !important; }
    .accent-text{ color: hsl(var(--accent)); }

    .grain-overlay{
      position: fixed; inset: 0; pointer-events: none; z-index: 0;
      background:
        radial-gradient(120% 60% at 50% 0%, rgba(255,255,255,0.06) 0%, rgba(0,0,0,0) 70%),
        radial-gradient(80% 40% at 80% 20%, rgba(255,255,255,0.04) 0%, rgba(0,0,0,0) 70%),
        url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='140' height='140' viewBox='0 0 140 140'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/><feColorMatrix type='saturate' values='0'/><feComponentTransfer><feFuncA type='table' tableValues='0 0 0 0 0.05 0.08 0.1 0.08 0.05 0'/></feComponentTransfer></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
      background-blend-mode: screen, normal, normal;
      opacity: .45;
    }

    .table{ width:100%; border-collapse: collapse; }
    .table th,.table td{ border-top:1px solid hsl(var(--border)); padding:12px; vertical-align: top; }
    .table tr > * + * { border-left:1px solid hsl(var(--border)); }
    a { text-decoration: none; color: inherit; }

    .list-ruled{ margin:0; padding:0; list-style:none; }
    .list-ruled .li-row{ display:flex; align-items:flex-start; gap:8px; padding:10px 0; }
    .list-ruled .li-row + .li-row{ border-top:1px solid hsl(var(--border)); }
    .ico{ width:16px; height:16px; flex:0 0 16px; margin-top:2px; }

    .row-strong td{ border-top:2px solid hsl(var(--border)); }
    .price-row td{ vertical-align: middle; }
    .price-stack{ display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:flex-start; }
    .price-stack.center{ justify-content:center; }

    .chip{
      display:inline-flex; align-items:center; gap:8px;
      padding:8px 12px; border-radius:9999px; font-weight:600;
      font-size:12px; line-height:1;
      border:1px solid rgba(255,153,51,.35);
      color:#fff; background:rgba(255,153,51,.12);
      white-space:nowrap; letter-spacing:.15px;
    }
    .badge-orange{
      display:inline-flex; align-items:center; gap:8px;
      padding:6px 10px; border-radius:9999px; font-weight:600; font-size:11px;
      border:1px solid rgba(255,153,51,.4); color:#ffae5d; background:rgba(255,153,51,.12);
    }
    .count-pill{
      display:inline-flex; align-items:center; gap:8px; padding:8px 12px;
      border-radius:12px; border:1px solid rgba(255,153,51,.35);
      background: rgba(255,153,51,.10);
      color:#fff; font-weight:600; font-size:13px; white-space:nowrap;
    }
    .count-band{
      display:flex; align-items:center; justify-content:center; gap:10px;
      padding:10px 14px; border:1px dashed rgba(255,153,51,.5);
      background: linear-gradient(90deg, rgba(255,153,51,.15), rgba(255,153,51,.06));
      border-radius:9999px; color:#fff; font-weight:700;
    }

    .cta-row{ display:flex; flex-wrap:wrap; gap:12px; align-items:center; justify-content:flex-start; }
    .cta-row.center{ justify-content:center; }

    /* >>> Grilles du quiz */
    .form-ruled{ border:1px solid rgba(255,255,255,.14); border-radius:12px; background: rgba(255,255,255,.02); overflow:hidden; }
    .form-ruled label{ display:flex; align-items:center; gap:10px; padding:10px 12px; line-height:1.35; }
    .form-ruled label + label{ border-top:1px solid rgba(255,255,255,.14); }
    input[type="checkbox"], input[type="radio"]{ width:16px; height:16px; accent-color:#ff9a3c; }

    /* >>> Unifie la hauteur des cartes de services */
    .service-card{ min-height: 640px; }

    /* >>> Glows encadrements */
    .glow-gold{ border-color: rgba(255,215,0,.45) !important; box-shadow:
      0 0 0 1px rgba(255,215,0,.25) inset,
      0 0 24px rgba(255,180,0,.18),
      0 0 2px rgba(255,215,0,.6);
    }
    .glow-purple{ border-color: rgba(168,85,247,.45) !important; box-shadow:
      0 0 0 1px rgba(168,85,247,.25) inset,
      0 0 24px rgba(168,85,247,.18),
      0 0 2px rgba(168,85,247,.6);
    }
    .glow-blue{ border-color: rgba(59,130,246,.45) !important; box-shadow:
      0 0 0 1px rgba(59,130,246,.25) inset,
      0 0 24px rgba(59,130,246,.18),
      0 0 2px rgba(59,130,246,.6);
    }
  `}</style>
);

const AnimatedBgStyles = () => (
  <style>{`
    .animated-bg{ position:absolute; inset:-20vmax; z-index:-2; pointer-events:none; opacity:.28; filter: blur(80px) saturate(110%);
      background:
       radial-gradient(120% 90% at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 85%, rgba(0,0,0,0.95) 100%),
       radial-gradient(40vmax 40vmax at 20% 10%, rgba(255,140,0,0.18), transparent 60%),
       radial-gradient(40vmax 40vmax at 80% 20%, rgba(0,200,255,0.14), transparent 60%),
       conic-gradient(from 0deg at 50% 50%, rgba(255,140,0,0.12), rgba(0,200,255,0.12), rgba(120,80,255,0.12), rgba(255,140,0,0.12));
      animation: swirl-rotate 28s linear infinite;
    }
    @keyframes swirl-rotate { 0%{transform:rotate(0) scale(1)} 50%{transform:rotate(180deg) scale(1.03)} 100%{transform:rotate(360deg) scale(1)} }
    @media (prefers-reduced-motion: reduce) { .animated-bg { animation: none; opacity: 0.18; } }

    /* HERO wrapper + fades */
    .hero{ position:relative; overflow:hidden; }
    .hero--band{ min-height: clamp(480px, 56vh, 760px); }
    .hero-fade-top, .hero-fade-bottom { position:absolute; left:0; right:0; pointer-events:none; z-index:-1; }
    .hero-fade-top { top:0; height:120px; background:linear-gradient(to bottom, rgba(0,0,0,1), rgba(0,0,0,0)); }
    .hero-fade-bottom { bottom:0; height:160px; background:linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0)); }

    /* Bandeau constellation aligné sur le conteneur (titre + vidéo) */
    .constellation-wrap{ position: relative; }
    .constellation-strip{
      position:absolute; left:0; right:0; top:0;
      pointer-events:none; z-index:0; opacity:1;
    }
    .constellation-strip--sm{ height: clamp(180px, 28vh, 320px); }
    .constellation-strip--md{ height: clamp(220px, 34vh, 380px); }
    .constellation-strip--xl{ height: clamp(320px, 48vh, 520px); }

    @media (max-width: 768px){
      .constellation-strip{ opacity:.95; }
    }
    .constellation-content{ position:relative; z-index:1; }
  `}</style>
);

/* ========= HERO CONSTELLATIONS (canvas) ========= */
/* Animation mouvement + scintillement + attraction souris */
function ConstellationCanvas({ className = "", style }) {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    let w = 0,
      h = 0;
    let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));

    let stars = [];
    let raf = 0;
    let running = false;
    const mouse = { x: 0, y: 0, active: false };

    const prefersReduce = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    const motionFactor = prefersReduce ? 0.4 : 1;

    const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

    function resize() {
      const rect = canvas.getBoundingClientRect();
      w = Math.max(1, Math.floor(rect.width));
      h = Math.max(1, Math.floor(rect.height));
      dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      spawn();
    }

    function spawn() {
      const target = clamp(Math.round((w * h) / 14000), 60, 220);
      stars = Array.from({ length: target }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.12 * motionFactor,
        vy: (Math.random() - 0.5) * 0.12 * motionFactor,
        r: Math.random() * 1.4 + 0.6,
        phase: Math.random() * Math.PI * 2,
        twSpeed: (Math.random() * 0.6 + 0.6) * motionFactor,
      }));
    }

    function step() {
      for (const s of stars) {
        s.x += s.vx;
        s.y += s.vy;
        if (s.x < 0 || s.x > w) s.vx *= -1;
        if (s.y < 0 || s.y > h) s.vy *= -1;

        if (mouse.active) {
          const dx = mouse.x - s.x;
          const dy = mouse.y - s.y;
          const d2 = dx * dx + dy * dy;
          const max = 200;
          if (d2 < max * max) {
            s.vx += (dx / (max * 80)) * motionFactor;
            s.vy += (dy / (max * 80)) * motionFactor;
          }
        }

        s.vx *= 0.996;
        s.vy *= 0.996;
      }
    }

    let t0 = 0;
    function draw(t) {
      if (!t0) t0 = t || 0;
      const dt = ((t || 0) - t0) / 1000;
      t0 = t || 0;

      ctx.clearRect(0, 0, w, h);

      // étoiles
      for (const s of stars) {
        const tw =
          0.55 + 0.45 * Math.sin(s.phase + (t || 0) * 0.002 * s.twSpeed);
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${0.8 * tw})`;
        ctx.shadowColor = "rgba(255,255,255,0.85)";
        ctx.shadowBlur = 8;
        ctx.arc(s.x, s.y, s.r * (0.8 + 0.4 * tw), 0, Math.PI * 2);
        ctx.fill();
      }

      // lignes (constellations)
      const maxDist =
        Math.min(180, Math.max(90, Math.sqrt(w * h) / 12)) *
        (window.innerWidth < 768 ? 1.0 : 1.15);

      ctx.lineWidth = 1;
      for (let i = 0; i < stars.length; i++) {
        for (let j = i + 1; j < stars.length; j++) {
          const a = stars[i];
          const b = stars[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < maxDist * maxDist) {
            const alpha = 1 - Math.sqrt(d2) / maxDist;
            const tw =
              0.5 +
              0.5 * Math.sin((a.phase + b.phase) * 0.5 + (t || 0) * 0.0015);
            ctx.strokeStyle = `rgba(255,153,51,${0.5 * alpha * tw})`;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
        if (mouse.active) {
          const a = stars[i];
          const dx = a.x - mouse.x;
          const dy = a.y - mouse.y;
          const d = Math.hypot(dx, dy);
          if (d < maxDist * 1.2) {
            const alpha = 1 - d / (maxDist * 1.2);
            ctx.strokeStyle = `rgba(255,153,51,${0.42 * alpha})`;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(mouse.x, mouse.y);
            ctx.stroke();
          }
        }
      }

      if (running) {
        step();
        raf = requestAnimationFrame(draw);
      }
    }

    function onMove(e) {
      const rect = canvas.getBoundingClientRect();
      mouse.x = (e.clientX || e.touches?.[0]?.clientX || 0) - rect.left;
      mouse.y = (e.clientY || e.touches?.[0]?.clientY || 0) - rect.top;
      mouse.active = true;
    }
    function onLeave() {
      mouse.active = false;
    }

    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.some((en) => en.isIntersecting);
        running = vis && !document.hidden;
        if (running) {
          cancelAnimationFrame(raf);
          raf = requestAnimationFrame(draw);
        }
      },
      { threshold: 0 }
    );

    const onVis = () => {
      running = !document.hidden;
      if (running) {
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(draw);
      }
    };

    const ro = new ResizeObserver(() => resize());

    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", onVis);
    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("touchmove", onMove, { passive: true });
    canvas.addEventListener("mouseleave", onLeave);
    canvas.addEventListener("touchend", onLeave);
    io.observe(canvas);
    ro.observe(canvas);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    resize();
    running = true;
    raf = requestAnimationFrame(draw);

    return () => {
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVis);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("touchmove", onMove);
      canvas.removeEventListener("mouseleave", onLeave);
      canvas.removeEventListener("touchend", onLeave);
      io.disconnect();
      ro.disconnect();
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className={className}
      style={{ width: "100%", ...style }}
      aria-hidden="true"
    />
  );
}

/* Logo */
const Logo = () => (
  <div className="flex items-center gap-3">
    <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-xl border border-subtle bg-card">
      <svg viewBox="0 0 24 24" className="h-5 w-5 accent-text" aria-hidden>
        <path
          d="M12 2l-2 5 3 3-2 3 3 3-2 5"
          stroke="currentColor"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
        />
      </svg>
    </span>
    <div className="leading-tight">
      <div className="text-base font-semibold tracking-tight">La Brèche</div>
      <div className="text-xs text-muted-foreground">Lifestyle & Business</div>
    </div>
  </div>
);

/* CountUp KPIs */
const useCountUp = (end, duration = 1200) => {
  const [value, setValue] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    let started = false;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting && !started) {
            started = true;
            const start = performance.now();
            const step = (now) => {
              const t = Math.min(1, (now - start) / duration);
              setValue(Math.floor(t * end));
              if (t < 1) requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
          }
        });
      },
      { threshold: 0.3 }
    );
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [end, duration]);
  return { value, ref };
};

/* ================== COOKIE & CONFETTI ================== */
const GA_MEASUREMENT_ID = "G-3FD9GZRP62";
const META_PIXEL_ID = "1441735960473865";
function loadGA4(id) {
  if (!id || id.includes("X")) return;
  if (document.getElementById("ga4-src")) return;
  const s = document.createElement("script");
  s.id = "ga4-src";
  s.async = true;
  s.src = "https://www.googletagmanager.com/gtag/js?id=" + id;
  document.head.appendChild(s);
  const i = document.createElement("script");
  i.id = "ga4-init";
  i.innerHTML = `window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', '${id}');`;
  document.head.appendChild(i);
}
function loadMetaPixel(id) {
  if (!id || /[^0-9]/.test(id)) return;
  if (window.fbq) return;
  const i = document.createElement("script");
  i.id = "meta-pixel";
  i.innerHTML = `!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
  n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);
  t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js'); fbq('init','${id}'); fbq('track','PageView');`;
  document.head.appendChild(i);
}
function CookieBanner() {
  const [consent, setConsent] = useState("unset");
  useEffect(() => {
    const saved = localStorage.getItem("cookie_consent") || "unset";
    setConsent(saved);
    if (saved === "granted") {
      loadGA4(GA_MEASUREMENT_ID);
      loadMetaPixel(META_PIXEL_ID);
    }
  }, []);
  if (consent !== "unset") return null;
  return (
    <div className="fixed bottom-4 left-4 right-4 z-[60] mx-auto max-w-3xl rounded-2xl border border-subtle bg-card p-4 shadow-lg">
      <div className="mb-2 text-sm font-medium">
        Cookies d’analyse & marketing
      </div>
      <p className="text-xs text-muted-foreground">
        GA4 & Meta Pixel pour analyser et améliorer l’expérience.
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button
          onClick={() => {
            localStorage.setItem("cookie_consent", "denied");
            setConsent("denied");
          }}
          className="rounded-xl border border-subtle px-3 py-1 text-sm"
        >
          Refuser
        </button>
        <button
          onClick={() => {
            localStorage.setItem("cookie_consent", "granted");
            setConsent("granted");
            loadGA4(GA_MEASUREMENT_ID);
            loadMetaPixel(META_PIXEL_ID);
          }}
          className="accent-btn px-3 py-1 text-sm rounded-2xl"
        >
          Accepter
        </button>
      </div>
    </div>
  );
}

async function ensureConfetti() {
  if (window.confetti) return window.confetti;
  await new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src =
      "https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js";
    s.async = true;
    s.onload = res;
    s.onerror = rej;
    document.head.appendChild(s);
  });
  return window.confetti;
}
async function fireConfettiBurst() {
  const confetti = await ensureConfetti();
  confetti({
    particleCount: 120,
    spread: 70,
    startVelocity: 45,
    origin: { y: 0.3 },
  });
}

/* ================== COUNTDOWN ================== */
function useCountdown(targetISO = "2025-09-30T23:59:59") {
  const [left, setLeft] = useState(() =>
    Math.max(0, new Date(targetISO).getTime() - Date.now())
  );
  useEffect(() => {
    const t = setInterval(
      () => setLeft(Math.max(0, new Date(targetISO).getTime() - Date.now())),
      1000
    );
    return () => clearInterval(t);
  }, [targetISO]);
  const s = Math.floor(left / 1000);
  const days = Math.floor(s / 86400);
  const hours = Math.floor((s % 86400) / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = s % 60;
  return { days, hours, minutes, seconds, done: left <= 0 };
}
const CountPill = ({ target }) => {
  const { days, hours, minutes, seconds } = useCountdown(target);
  return (
    <div className="count-pill">
      <Clock className="h-4 w-4 accent-text" />
      <span className="opacity-90">prévente ouverte — lancement dans</span>
      <strong>
        {days}j {hours}h {minutes}m {seconds}s
      </strong>
    </div>
  );
};
const CountBand = ({ target }) => {
  const { days, hours, minutes, seconds } = useCountdown(target);
  return (
    <div className="count-band">
      <Clock className="h-4 w-4 accent-text" />
      <span>PRÉVENTE OUVERTE — LANCEMENT DANS</span>
      <span className="font-black">
        {days}j {hours}h {minutes}m {seconds}s
      </span>
    </div>
  );
};

/* ================== WISTIA EMBED (autoplay, léger) ================== */
// On garde le même nom de composant (YouTubeEmbed) pour ne rien casser.
// Il pointe maintenant vers Wistia.
const WISTIA_DEFAULT_ID = "94gpwgvpzf"; // https://kaissania.wistia.com/medias/94gpwgvpzf
const YouTubeEmbed = ({
  id = WISTIA_DEFAULT_ID,
  title = "Présentation",
  start = 0,
  autoplay = true,
}) => {
  const timeParam = start > 0 ? `&time=${start}s` : "";
  return (
    <iframe
      src={`https://fast.wistia.net/embed/iframe/${id}?autoplay=${
        autoplay ? 1 : 0
      }&muted=1&playsinline=1&seo=false${timeParam}`}
      title={title}
      allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
      allowFullScreen
      loading="lazy"
      style={{ width: "100%", height: "100%", border: 0 }}
      referrerPolicy="strict-origin-when-cross-origin"
    />
  );
};
// Conserve la constante utilisée ailleurs pour les témoignages
const YOUTUBE_ID = WISTIA_DEFAULT_ID;

/* ================== EMAILOCTOPUS (anti-duplication) ================== */
function EmailOctopusEmbed({ formId, id, onSuccess }) {
  const containerRef = useRef(null);
  const mountedOnce = useRef(false);
  const successOnce = useRef(false);

  useEffect(() => {
    if (!formId || mountedOnce.current) return;
    mountedOnce.current = true;

    const el = containerRef.current;
    if (!el) return;
    el.innerHTML = "";

    if (el.querySelector(`script[data-form="${formId}"]`)) return;

    const s = document.createElement("script");
    s.async = true;
    s.src = `https://eocampaign1.com/form/${formId}.js`;
    s.dataset.form = formId;
    el.appendChild(s);

    const obs = new MutationObserver(() => {
      if (successOnce.current) return;
      const txt = el?.textContent?.toLowerCase() || "";
      const hit =
        el?.querySelector(".emailoctopus-success") ||
        txt.includes("thank") ||
        txt.includes("merci") ||
        txt.includes("thanks");
      if (hit) {
        successOnce.current = true;
        onSuccess && onSuccess();
        obs.disconnect();
      }
    });
    obs.observe(el, { childList: true, subtree: true, characterData: true });

    return () => {
      obs.disconnect();
    };
  }, [formId, onSuccess]);

  return <div id={id} ref={containerRef} className="w-full" />;
}

/* ================== QUIZ ================== */
function EligibilityQuiz({ slots, calendly }) {
  const [budget, setBudget] = useState("");
  const [goals, setGoals] = useState({
    education: false,
    time: false,
    calmControl: false,
    ecosystem: false,
    community: false,
  });
  const [attitudes, setAttitudes] = useState({
    quickEasyMoney: false,
    nothingToLearn: false,
    getRichFast: false,
  });
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  const onSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    const budgetOk = budget === "900-2000" || budget === "2000plus";
    const hardNo =
      attitudes.quickEasyMoney ||
      attitudes.nothingToLearn ||
      attitudes.getRichFast;
    const positives =
      Number(goals.education) +
      Number(goals.time) +
      Number(goals.calmControl) +
      Number(goals.ecosystem) +
      Number(goals.community);
    const eligible = budgetOk && !hardNo && positives >= 2;
    if (eligible) {
      setResult({ eligible: true, reason: "Profil aligné." });
      setSubmitting(false);
      fireConfettiBurst();
      return;
    }
    let reason = "Profil non aligné pour le moment.";
    if (!budgetOk)
      reason = "Budget actuel insuffisant pour l’accompagnement premium.";
    else if (hardNo)
      reason = "Attentes incompatibles (gains rapides, pas d’apprentissage…).";
    else if (positives < 2)
      reason = "Objectifs trop flous : précise au moins deux priorités.";
    setResult({ eligible: false, reason });
    setSubmitting(false);
  };

  return (
    <form onSubmit={onSubmit} className="space-y-6 text-sm">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-subtle p-4">
          <div className="mb-3 inline-flex items-center gap-2 badge-orange">
            <Info className="h-3.5 w-3.5" /> Budget disponible
          </div>
          <div className="form-ruled">
            {["50-200", "200-700", "900-2000", "2000plus"].map((val) => (
              <label key={val}>
                <input
                  type="radio"
                  name="budget"
                  value={val}
                  onChange={(e) => setBudget(e.target.value)}
                />{" "}
                {val === "2000plus"
                  ? "> 2 000 €"
                  : val.replace("-", " - ") + " €"}
              </label>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-subtle p-4">
          <div className="mb-3 inline-flex items-center gap-2 badge-orange">
            <Info className="h-3.5 w-3.5" /> Objectifs & Attentes
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="form-ruled">
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setGoals((g) => ({ ...g, education: e.target.checked }))
                  }
                />{" "}
                S’éduquer financièrement
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setGoals((g) => ({ ...g, time: e.target.checked }))
                  }
                />{" "}
                Gagner du temps
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setGoals((g) => ({ ...g, calmControl: e.target.checked }))
                  }
                />{" "}
                Moins de stress & plus de contrôle
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setGoals((g) => ({ ...g, ecosystem: e.target.checked }))
                  }
                />{" "}
                Écosystème IA pour investir
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setGoals((g) => ({ ...g, community: e.target.checked }))
                  }
                />{" "}
                Communauté alignée
              </label>
            </div>
            <div className="form-ruled">
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setAttitudes((a) => ({
                      ...a,
                      quickEasyMoney: e.target.checked,
                    }))
                  }
                />{" "}
                Argent rapide & facile
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setAttitudes((a) => ({
                      ...a,
                      nothingToLearn: e.target.checked,
                    }))
                  }
                />{" "}
                Ne rien apprendre
              </label>
              <label>
                <input
                  type="checkbox"
                  onChange={(e) =>
                    setAttitudes((a) => ({
                      ...a,
                      getRichFast: e.target.checked,
                    }))
                  }
                />{" "}
                Devenir riche très vite
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs text-muted-foreground">
          <Clock className="inline mr-1 h-3.5 w-3.5 accent-text" /> {slots}{" "}
          places disponibles
        </div>
        <Button type="submit" disabled={!budget || submitting}>
          {submitting ? "Analyse…" : "Valider"}
        </Button>
      </div>

      {result && result.eligible && (
        <>
          <div className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-200">
            <div className="flex items-start gap-2">
              <Check className="mt-0.5 h-5 w-5" />
              <div>
                <div className="font-medium">Éligible — bravo 🎉</div>
                <div className="text-xs opacity-90">{result.reason}</div>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex flex-wrap gap-2">
              {calendly && (
                <Button asChild className="outline">
                  <a href={calendly} target="_blank" rel="noopener noreferrer">
                    <Calendar className="mr-2 h-4" /> Ouvrir Calendly
                  </a>
                </Button>
              )}
            </div>
            {calendly && (
              <div className="mt-3 rounded-xl overflow-hidden border border-subtle">
                <iframe
                  title="Calendly"
                  src={`${calendly}?hide_gdpr_banner=1`}
                  className="w-full bg-card"
                  style={{ height: "640px", border: "0" }}
                />
              </div>
            )}
          </div>
        </>
      )}
      {result && !result.eligible && (
        <div className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-red-200">
          <div className="flex items-start gap-2">
            <XCircle className="mt-0.5 h-5 w-5" />
            <div>
              <div className="font-medium">Inéligible pour le moment</div>
              <div className="text-xs opacity-90">{result.reason}</div>
            </div>
          </div>
        </div>
      )}
    </form>
  );
}

/* ================== PRE-SALE PAGE ================== */
function PreSalePage({ onBack, PREV_TARGET, FORM_ID_PRE }) {
  return (
    <div className="min-h-screen relative">
      <GlobalThemeStyles />
      <AnimatedBgStyles />
      <div className="grain-overlay" aria-hidden="true"></div>

      <header className="sticky top-0 z-50 border-b border-subtle bg-black/70 backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#/" className="flex items-center gap-2">
            <Logo />
          </a>
          <Button onClick={onBack}>← Retour au site</Button>
        </nav>
      </header>

      {/* HERO PRÉVENTE : constellations (XL) */}
      <section id="prevente-hero" className="hero hero--band">
        <div className="hero-fade-top" />
        <div className="hero-fade-bottom" />

        <div className="mx-auto max-w-4xl px-4 py-12 md:py-16">
          <div className="constellation-wrap">
            <ConstellationCanvas className="constellation-strip constellation-strip--xl" />
            <div className="space-y-6 constellation-content">
              <CountBand target={PREV_TARGET} />

              <div className="text-center">
                <h1 className="mt-2 text-3xl md:text-4xl font-semibold">
                  Prévente — Réserve ta place au lancement
                </h1>
                <p className="mt-2 text-sm text-muted-foreground">
                  "La brèche" est ouverte en prévente ! en y participant tu aura
                  accès à des cours exclusifs, des lives en avant-première, des
                  avantages au sein de la formation ainsi que la possibilité de
                  pouvoir contribuer à la conception de la formation finale avec
                  moi !
                </p>
              </div>

              <div className="flex justify-center">
                <CountPill target={PREV_TARGET} />
              </div>

              <div className="mt-2">
                <div className="aspect-video w-full overflow-hidden rounded-2xl border border-subtle bg-card">
                  <YouTubeEmbed title="Prévente - Présentation" />
                </div>
              </div>

              <Card className="mt-2">
                <CardContent>
                  <ul className="list-ruled text-sm">
                    <li className="li-row">
                      <Check className="ico accent-text" /> maximum 20 Places —
                      accède au prix de lancement pendant 3 mois.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Lives, exclusif
                      (Q&A, marchés, ateliers IA).
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Contribution à la
                      conception de la formation finale & feedback.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Bonus exclusifs à
                      vie pour ceux qui prennent l'offre de pré-lancement
                      maintenant.
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Réserver ma place maintenant !</CardTitle>
                </CardHeader>
                <CardContent>
                  <EmailOctopusEmbed
                    id="emailocto-presale"
                    formId={FORM_ID_PRE}
                    onSuccess={() => fireConfettiBurst()}
                  />
                </CardContent>
              </Card>

              <div className="flex justify-center">
                <Button onClick={onBack}>← Retour au site</Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/* ================== MAIN SITE ================== */
function SiteLaBreche({ goPreSale }) {
  const EBOOK_URL = "https://alyaneebook.my.canva.site/";
  const CALENDLY_URL = "https://calendly.com/ton-calendly/20min";
  const SLOTS_AVAILABLE = 14;
  const FORM_ID_EBOOK = "3e471948-7877-11f0-b0cb-3bc085a6eaa0";
  const FORM_ID_PRE = "3e471948-7877-11f0-b0cb-3bc085a6eaa0";
  const PREV_TARGET = "2025-09-30T23:59:59";

  const IMG = {
    about1: "/media/about_1.jpg.jpg",
    about2: "/media/about_2.jpg.jpg",
    about3: "/media/about_3.jpg.png",
    about4: "/media/about_4.jpg.jpg",
    formation: "/media/formation_cover.jpg.jpg",
    software: "/media/software_cover.jpg.jpg",
  };
  const VIDEO = "/media/hero_intro.mp4.mp4";

  // MODIF: passe de 1000 -> 200 (pour afficher "200k")
  const { value: clientsValue, ref: clientsRef } = useCountUp(200);
  const { value: countriesValue, ref: countriesRef } = useCountUp(60);

  function openLegalPage() {
    const w = window.open("/mentions-legales", "_blank");
    if (!w) return;
    w.document.write(
      `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Mentions légales</title></head><body>Mentions à venir.</body></html>`
    );
    w.document.close();
  }

  const scrollToEmbed = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen relative">
      <GlobalThemeStyles />
      <AnimatedBgStyles />
      <div className="grain-overlay" aria-hidden="true"></div>

      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-subtle bg-black/70 backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#/" className="flex items-center gap-2">
            <Logo />
          </a>
          <div className="hidden items-center gap-6 md:flex">
            <a href="#about" className="text-sm hover:opacity-80">
              Mon histoire
            </a>
            <a href="#services" className="text-sm hover:opacity-80">
              Services
            </a>
            <a href="#formation" className="text-sm hover:opacity-80">
              Formation
            </a>
            <a href="#pourquoi-nous" className="text-sm hover:opacity-80">
              Pourquoi nous
            </a>
            <a href="#preuves" className="text-sm hover:opacity-80">
              Chiffres clés
            </a>
            <a href="#temoignages" className="text-sm hover:opacity-80">
              Témoignages
            </a>
            <a href="#faq" className="text-sm hover:opacity-80">
              FAQ
            </a>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild>
              <a href="#services">
                <ArrowRight className="mr-2 h-4 w-4" /> Mes services
              </a>
            </Button>
          </div>
        </nav>
      </header>

      {/* HERO principal : constellations (XL) */}
      <section id="home" className="hero hero--band">
        <div className="hero-fade-top" />
        <div className="hero-fade-bottom" />

        <div className="mx-auto max-w-6xl px-4 py-16 md:py-24">
          <div className="constellation-wrap">
            <ConstellationCanvas className="constellation-strip constellation-strip--xl" />
            <div className="grid constellation-content max-w-none items-center gap-10 md:grid-cols-2">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="mb-4 text-4xl font-semibold leading-tight tracking-tight md:text-5xl accent-text">
                  Forme ton esprit, structure tes finances et utilise l’IA comme
                  copilote pour garder le contrôle sur ton avenir
                </h1>
                <p className="mb-6 text-base text-muted-foreground md:text-lg">
                  Construis une méthode simple, investis sur les marchés avec
                  plus de clarté et utilise l'IA pour automatiser et reprendre
                  le contrôle de ton portefeuille de façon intélligente.
                </p>
                <div className="cta-row">
                  <Button onClick={() => scrollToEmbed("emailocto-main")}>
                    🧭 Commencer en 3 minutes (ebook)
                  </Button>
                  <Button onClick={goPreSale}>Voir la formation</Button>
                </div>
                <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 accent-text" /> Paiement
                    sécurisé
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 accent-text" /> +1 000
                    clients accompagnés
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 accent-text" /> 4,5
                    <span className="text-base">/5</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="relative"
              >
                <div className="aspect-video overflow-hidden rounded-2xl border border-subtle shadow-sm bg-card">
                  <YouTubeEmbed title="Présentation" />
                </div>
                <a
                  href="#services"
                  className="mt-3 inline-flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
                >
                  <ArrowRight className="h-4 w-4" /> découvrir les services
                </a>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* EBOOK — sans constellations */}
      <Section
        id="ebook"
        title="Ton ebook gratuit — la base solide pour agir"
        kicker="Ressources"
      >
        <div className="grid items-start gap-10 md:grid-cols-[1.1fr_0.9fr]">
          <div className="prose prose-invert max-w-none">
            <h3 className="mt-1">
              Comprends l’argent et avance avec un plan clair
            </h3>
            <p className="text-sm text-neutral-300 mt-4">
              Cet ebook t’aide à clarifier le fonctionnement de l’argent, éviter
              les erreurs qui coûtent cher, te faire prendre conscience que ta
              retraite n'est plus assurée et utiliser l’IA comme levier pour
              pour reprendre le contrôle sur ton avenir.
            </p>
            <ul className="list-ruled mt-6">
              <li className="li-row">
                <Check className="ico accent-text" /> Comprendre le code caché
                et les secrets de l'argent
              </li>
              <li className="li-row">
                <Check className="ico accent-text" /> Éviter les 7 péchés
                capitaux dans l'investissement.
              </li>
              <li className="li-row">
                <Check className="ico accent-text" /> découvrir une IA que
                personne ne parle encore afin de créer des stratégies gérer par
                l'IA et d'automatiser tes investissements.
              </li>
              <li className="li-row">
                <Check className="ico accent-text" /> Comprendre et appliquer le
                Triangle d'Or de l'eveil financier
              </li>
              <li className="li-row">
                <Check className="ico accent-text" /> comment débuter avec un
                plan clair et structuré
              </li>
              <li className="li-row">
                <Check className="ico accent-text" /> bonus vidéo exclusif
                uniquement pour ceux qui ont accès à l'ebook
              </li>
            </ul>
            <div className="cta-row mt-6">
              <Button onClick={() => scrollToEmbed("emailocto-main")}>
                <BookOpen className="mr-2 h-4 w-4" /> Accès via e-mail
              </Button>
              <Button onClick={() => scrollToEmbed("formation")}>
                <ArrowRight className="mr-2 h-4 w-4" /> Découvrir la formation
              </Button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              vérifie tes spams si tu ne reçois pas l'ebook !
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recevoir l’ebook par e-mail</CardTitle>
            </CardHeader>
            <CardContent>
              <EmailOctopusEmbed
                id="emailocto-main"
                formId={FORM_ID_EBOOK}
                onSuccess={() => fireConfettiBurst()}
              />
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* ABOUT — vidéo + résumé + CTA */}
      <Section id="about" title="Mon histoire" kicker="À propos">
        <div className="mx-auto max-w-3xl space-y-6">
          <p className="text-sm text-neutral-300">
            Parti de zéro dans un environnement instable, j’ai choisi de
            reprendre le contrôle au lycée. Après un essai en e-commerce raté,
            j’ai étudié l’investissement chaque jour pendant 3ans même si je ne
            pouvais pas investir dû à ma situation je me suis quand même lancer
            (crypto/NFT,bourse...). Le déclic : l’IA, un modèle et une
            entreprise méconnu en France à très haut potentiel. J’ai automatisé,
            structuré mes offres et commencé à transmettre. Aujourd’hui, 1 000+
            personnes accompagnées. Ma mission : t’aider à clarifier, investir
            et garder le contrôle sur tes finances de la manière la plus
            pédagogique possible.
          </p>

          <div className="aspect-video overflow-hidden rounded-2xl border border-subtle bg-card">
            <YouTubeEmbed
              id={YOUTUBE_ID}
              title="Mon histoire — La Brèche"
              autoplay={false}
            />
          </div>

          <div className="cta-row center">
            <Button asChild>
              <a href="#services">
                <ArrowRight className="mr-2 h-4 w-4" /> Découvre mes services
              </a>
            </Button>
          </div>
        </div>
      </Section>

      {/* MES CHIFFRES — style SGM (icônes + accent orange) */}
      <Section id="mes-chiffres" title="Mes chiffres" kicker="Repères">
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-4xl md:text-5xl font-semibold">
                <BarChart3 className="h-6 w-6 accent-text" /> 1&nbsp;000
                <span className="text-lg md:text-xl align-super">+</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                clients accompagnés
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-4xl md:text-5xl font-semibold">
                <Award className="h-6 w-6 accent-text" /> 5
                <span className="text-lg md:text-xl align-super">ans</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                d’expérience dans les marchés
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-2xl md:text-3xl font-semibold">
                <ShieldCheck className="h-6 w-6 accent-text" /> Accompagnement
                pas à pas
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                méthode guidée & concrète
              </p>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* SKOOL / FORMATION & COMMUNAUTÉ — sans constellations */}
      <Section id="formation" title="Formation & Communauté" kicker="Skool">
        <div className="mb-6">
          <CountPill target={PREV_TARGET} />
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="prose prose-invert max-w-none">
            <h3 className="!mt-0">
              Passe de zéro à la <em>maîtrise</em> en 30 jours
            </h3>
            <p className="text-sm text-muted-foreground">
              Commence aujourd’hui et avance avec discipline — découvre comment
              tu peux reprendre le contrôle de ton avenir en 30 jours avec 5ans
              de conseil résumé et conçu pour que tu sois prêt en 30j.
            </p>

            <div className="mt-4 grid gap-3">
              <div className="rounded-xl border border-subtle bg-card p-4">
                <ul className="list-ruled">
                  <li className="li-row">
                    <Check className="ico accent-text" /> Parcours guidé pas à
                    pas avec 7 modules.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Exercices actionnables
                    en direct + retours personalisés.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Lives hebdo &
                    investissements personnel en direct live.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> découverte gratuite de
                    l'IA que j'utilise comme copilote pour analyser, décider &
                    opérer automatiquement sur le marché.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> mise à jour de la
                    formation et des modules quotidiennement avec vous.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Fiches PDF pratiques &
                    bonus ( concours, exclusivité...).
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Accès communauté &
                    entraide.
                  </li>
                </ul>
              </div>
            </div>

            <div className="cta-row mt-3">
              <Button onClick={goPreSale}>
                <ShoppingCart className="mr-2 h-4 w-4" /> Réserver ma place ( 20
                places restantes )
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>BiENVENUE DANS LA BRECHE !</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 accent-text" /> Pour débutant
                  & avancé (parcours guidé)
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 accent-text" /> Accès
                  immédiat après paiement
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 accent-text" /> information
                  structuré et applicable dès le 1er jour
                </li>
                <li className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 accent-text" /> concours +
                  lives réguliers
                </li>
              </ul>
              <div className="mt-4">
                <div className="aspect-video w-full overflow-hidden rounded-xl border border-subtle bg-card">
                  <YouTubeEmbed title="FAQ Paiement & Accès" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* SOFTWARE IA — sans constellations */}
      <Section
        id="softwareia"
        title="Software IA — Accompagnement sur sélection"
        kicker="Offre premium"
      >
        <div className="grid gap-8 md:grid-cols-2">
          <Card>
            <CardHeader className="space-y-3">
              <div className="badge-orange">
                <Clock className="h-3.5 w-3.5" /> {SLOTS_AVAILABLE} places
                disponibles
              </div>
              <CardTitle>Processus d’admission</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal space-y-2 pl-5 text-sm">
                <li>Quizz rapide (10sec)</li>
                <li>Appel d'1heure pour faire conaissance</li>
                <li>Validation du profil & objectifs</li>
                <li>Onboarding et plan d’action directement</li>
              </ol>

              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 text-sm">
                <div className="rounded-xl border border-subtle p-3">
                  <div className="badge-orange">
                    <Check className="h-4 w-4" /> Profil idéal
                  </div>
                  <ul className="mt-2 list-ruled">
                    <li className="li-row">
                      <Check className="ico accent-text" /> Budget 1 000–3 000 €
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> souhaite s'éduquer
                      financièrement
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> souhaite évoluer et
                      prendre en main sa situation
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Volonté d’apprendre
                      et de pouvoir passer à l'action
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" />
                      faire partie d'une communauté qui évolue ensemble
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> vouloir se faire
                      accompagné par un mentor et une communauté
                    </li>
                  </ul>
                </div>
                <div className="rounded-xl border border-subtle p-3">
                  <div className="badge-orange">
                    <XCircle className="h-4 w-4" /> profil non adapté
                  </div>
                  <ul className="mt-2 list-ruled">
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Pas prêt à
                      investir
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Recherche
                      d’argent facile
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Refus
                      d’apprentissage
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Souhaite être
                      riche dans 2 mois
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> vouloir tout
                      faire soi-même
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> à voir ici
                    </li>
                  </ul>
                </div>
              </div>

              <div className="mt-4 cta-row center">
                <Button
                  onClick={() =>
                    document
                      .getElementById("softwareia-quiz")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                >
                  <Calendar className="mr-2 h-4" /> Vérifier mon éligibilité
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle>Pourquoi ce Software IA</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <ul className="list-ruled text-sm text-muted-foreground">
                <li className="li-row">
                  <Check className="ico accent-text" /> Automatisées vos
                  stratégies pilotées par l'IA et gagner du temps et de la
                  sérenité sur votre portefeuille.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Réduire les pertes tout
                  en maximisant les gains grâce aux stratégies intélligentes et
                  leurs différentes façon de s'adapter au marché
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Améliorer les décisions
                  avec IA comme copilote et tout son ecosytème intélligent
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Transparence, contrôle
                  total & aucun frais de performance.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Intégration API claire à
                  votre exchange favori.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Onboarding guidé dans un
                  compte demo.
                </li>
              </ul>
              <div className="mt-6">
                <div className="aspect-[16/9] w-full overflow-hidden rounded-xl border border-subtle bg-card">
                  <YouTubeEmbed title="Aperçu Software IA" />
                </div>
                <p className="mt-2 text-xs text-muted-foreground text-center">
                  pour plus d'info, passe le quizz ci-dessous
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* QUIZ */}
        <div id="softwareia-quiz" className="mt-10">
          <Card>
            <CardHeader className="space-y-2">
              <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                <Info className="h-4 w-4 accent-text" /> Réponds en 30 secondes
                — résultat immédiat.
              </div>
              <CardTitle>Quiz d’éligibilité — Software IA</CardTitle>
            </CardHeader>
            <CardContent>
              <EligibilityQuiz
                slots={SLOTS_AVAILABLE}
                calendly={"https://calendly.com/ton-calendly/20min"}
              />
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* SERVICES — sans constellations */}
      <Section id="services" title="Mes services" kicker="Offres">
        <div className="grid gap-6 md:grid-cols-3 items-stretch">
          {/* EBOOK */}
          <Card className="service-card h-full flex flex-col overflow-hidden glow-blue">
            <div className="aspect-[16/9] w-full overflow-hidden">
              <img
                src={IMG.about4}
                alt="Couverture Ebook"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <CardHeader>
              <CardTitle className="flex items-center justify-between gap-3">
                Ebook gratuit <span className="badge-orange">Offert</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 flex-1 flex flex-col">
              <ul className="list-ruled">
                <li className="li-row">
                  <Check className="ico accent-text" /> Bases claires pour
                  décider sans te disperser.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Éviter les erreurs
                  coûteuses.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> découvre comment l'IA
                  peut changer ton approche de l'investissement
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> mieux comprendre comment
                  fonctionne le système et ses pièges
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" />
                  découvre le Triangle d'Or de l'investisseur
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Accès via e-mail, mises
                  à jour & bonus.
                </li>
              </ul>
              <div className="cta-row center mt-auto">
                <Button onClick={() => scrollToEmbed("emailocto-main")}>
                  <BookOpen className="mr-2 h-4 w-4" /> Accès via e-mail
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* FORMATION + COMMUNAUTÉ */}
          <div className="grid grid-rows-[auto_1fr] h-full">
            <div className="mb-2 flex justify-center">
              <CountPill target={PREV_TARGET} />
            </div>

            <Card className="service-card h-full flex flex-col overflow-hidden glow-gold">
              <div className="aspect-[16/9] w-full overflow-hidden">
                <img
                  src={IMG.formation}
                  alt="Couverture Formation"
                  className="h-full w-full object-cover"
                  loading="lazy"
                />
              </div>
              <CardHeader className="space-y-2">
                <div className="badge-orange">La Brèche - Skool</div>
                <CardTitle>Formation & Communauté</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 flex-1 flex flex-col">
                <ul className="list-ruled">
                  <li className="li-row">
                    <Check className="ico accent-text" /> Parcours guidé +
                    exercices pratique.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Live investissement en
                    direct avec toi
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> découverte d'outils &
                    accompagnement communautaire
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> modules conçu pour te
                    faire progresser jusqu’à ta compréhension de
                    l'investissement et des marchés.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Fiches PDF + bonus de
                    lancement.
                  </li>
                  <li className="li-row">
                    <Check className="ico accent-text" /> Accès prioritaire aux
                    nouveautés & bonus pour l'offre de lancement.
                  </li>
                </ul>
                <div className="cta-row center mt-auto">
                  <Button onClick={goPreSale}>
                    <ShoppingCart className="mr-2 h-4 w-4" /> Réserver ma place
                    (20 places restantes)
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* SOFTWARE IA */}
          <Card className="service-card h-full flex flex-col overflow-hidden glow-purple">
            <div className="aspect-[16/9] w-full overflow-hidden">
              <img
                src={IMG.software}
                alt="Couverture Software IA"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <CardHeader className="space-y-3">
              <div className="badge-orange">Appel requis</div>
              <CardTitle>Software IA</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 flex-1 flex flex-col">
              <ul className="list-ruled">
                <li className="li-row">
                  <Check className="ico accent-text" /> Automatisation de
                  stratégies intélligentes
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Transparence & contrôle
                  totale.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> pas de frais de
                  performance.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> ecosytème AI complet
                  pour piloter tes décisions.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> Intégration exchange
                  régulé via API & DEX.
                </li>
                <li className="li-row">
                  <Check className="ico accent-text" /> conçu et pensé pour les
                  débutants & experts
                </li>
              </ul>
              <div className="cta-row center mt-auto">
                <Button
                  onClick={() =>
                    document
                      .getElementById("softwareia")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                >
                  <Calendar className="mr-2 h-4" /> Vérifier mon éligibilité
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* TÉMOIGNAGES — sans constellations */}
      <Section
        id="temoignages"
        title="Ils ont franchi la brèche"
        kicker="Témoignages vidéo"
      >
        <div className="grid gap-6 md:grid-cols-2">
          {[
            {
              name: "Amine B.",
              role: "Entrepreneur",
              img: "/media/testimonial_amine.jpg",
              ytId: YOUTUBE_ID,
              text: "L’ebook m’a clarifié les bases. La formation m’a donné une cadence simple pour agir.",
            },
            {
              name: "Sarah M.",
              role: "Indépendante",
              img: "/media/testimonial_sarah.jpg",
              ytId: YOUTUBE_ID,
              text: "Ici, c’est concret, pratique. L’IA est un copilote, pas une baguette magique.",
            },
            {
              name: "Hugo L.",
              role: "Freelance",
              img: "/media/testimonial_hugo.jpg",
              ytId: YOUTUBE_ID,
              text: "Le quiz m’a rassuré. L’accompagnement m’a fait gagner du temps et du calme.",
            },
            {
              name: "Lina K.",
              role: "Étudiante",
              img: "/media/testimonial_lina.jpg",
              ytId: YOUTUBE_ID,
              text: "Structure claire + communauté qui pousse à exécuter — ça change tout.",
            },
          ].map((t, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="aspect-video w-full overflow-hidden rounded-xl border border-subtle bg-card">
                  <YouTubeEmbed
                    id={t.ytId}
                    title={`Témoignage — ${t.name}`}
                    autoplay={false}
                  />
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <img
                    src={t.img}
                    alt={t.name}
                    className="h-10 w-10 rounded-full object-cover border border-subtle"
                    loading="lazy"
                  />
                  <div>
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-neutral-400">{t.role}</div>
                  </div>
                </div>

                <div
                  className="mt-3 flex items-center gap-1 text-amber-400"
                  aria-label="5 étoiles"
                >
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="mt-3 text-sm text-neutral-200">{t.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* POURQUOI NOUS — sans constellations */}
      <Section
        id="pourquoi-nous"
        title="Pourquoi nous ?"
        kicker="Comparatif clair"
      >
        <p className="mb-6 max-w-3xl text-sm text-muted-foreground">
          Comparatif synthétique entre notre formation, l’offre moyenne des
          formations sur internet, l’écosystème SGM et les solutions d’IA sur
          internet.
        </p>
        <div className="overflow-x-auto rounded-2xl border border-subtle">
          <table className="table text-sm align-top">
            <thead>
              <tr>
                <th className="text-left text-muted-foreground w-[160px]">
                  Noms
                </th>
                <th className="text-left">LA BRÈCHE (formation)</th>
                <th className="text-left">Formation internet</th>
                <th className="text-left">Écosystème SGM</th>
                <th className="text-left">IA internet</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="text-muted-foreground font-medium">Inclus</td>
                <td>
                  <ul className="list-ruled">
                    <li className="li-row">
                      <Check className="ico accent-text" /> Formation à 360°.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> 700+ heures de
                      formations en 7 modules intélligents.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Suivi communautaire.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> découverte d'outil
                      AI exclusif.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> mise à jour continue
                      de la formation.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Pensée pour
                      accompagner les débutants et affiner les avancés.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> entraide communauté
                      active.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Exercices pratiques
                      & investissement exécutés en lives.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> concours et bonus
                      tout au long de la formation.
                    </li>
                  </ul>
                </td>
                <td>
                  <ul className="list-ruled">
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Formation rapide
                      & basic.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Suivi possible.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Pas d'information
                      sur des outils exclusif.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Prix souvent
                      élevés.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Beaucoup de
                      théorie, peu de pratique et d'action.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Communauté.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Formateurs peu
                      accessibles directement.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Mises à jour
                      rares, les formations sont statiques.
                    </li>
                  </ul>
                </td>
                <td>
                  <ul className="list-ruled">
                    <li className="li-row">
                      <Check className="ico accent-text" /> Fonds sécurisés (
                      connexion API exchange régulé UE).
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Contrôle total sur
                      stratégies.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Transparence des
                      transactions.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> 0 % de frais sur la
                      plateforme.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Best European
                      Technology Awards 2024.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> 200 000+ clients /
                      4,5/5.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Écosystème IA (15+
                      services).
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> onboarding simple
                      clé en main.
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> 1B+ volume (2024) /
                      14M+ ordres (2024).
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Fondateurs cités
                      (Forbes…).
                    </li>
                    <li className="li-row">
                      <Check className="ico accent-text" /> Entreprise &gt; 200
                      M€ CA/an.
                    </li>
                  </ul>
                </td>
                <td>
                  <ul className="list-ruled">
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Plateformes non
                      régulées.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Full automatisé —
                      aucun contrôle.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Opacité du
                      système ( risque).
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Fondateurs
                      anonymes.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Frais par
                      transaction ou performance.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Pas d’écosystème
                      AI complet.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Données
                      insuffisantes et avis inéxistant.
                    </li>
                    <li className="li-row">
                      <XCircle className="ico text-red-400" /> Société non
                      fiable.
                    </li>
                  </ul>
                </td>
              </tr>

              {/* PRIX */}
              <tr className="row-strong price-row">
                <td className="text-muted-foreground font-medium">Prix</td>
                <td>
                  <div className="price-stack">
                    <span className="chip">offre de prévente 39 € / mois</span>
                    <span className="chip"> offre de prévente 389 € / an</span>
                  </div>
                  <div className="mt-2">
                    <Button onClick={() => scrollToEmbed("formation")}>
                      Rejoindre la prévente
                    </Button>
                  </div>
                </td>
                <td>
                  <div className="price-stack center">
                    <span className="chip">500–1 500 €</span>
                  </div>
                </td>
                <td>
                  <div className="cta-row center">
                    <Button onClick={() => scrollToEmbed("softwareia")}>
                      Réserver son appel
                    </Button>
                  </div>
                </td>
                <td>
                  <div className="price-stack">
                    <span className="chip">1 500–5 000 € / an</span>
                    <span className="chip">ou 300–500 € / mois</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-xs text-muted-foreground"></p>
      </Section>

      {/* CHIFFRES CLÉS — sans constellations */}
      <Section id="preuves" title="Software SGM" kicker="Chiffres clés">
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardContent className="p-6 text-center">
              <div
                ref={clientsRef}
                className="flex items-center justify-center gap-2 text-4xl md:text-5xl font-semibold"
              >
                <BarChart3 className="h-6 w-6 accent-text" /> {clientsValue}
                <span className="text-lg md:text-xl align-super">k</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                clients dans le monde
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-3xl md:text-4xl font-semibold">
                <Star className="h-6 w-6 accent-text" /> 4,5
                <span className="text-base">/5</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                note Trustpilot
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div
                ref={countriesRef}
                className="flex items-center justify-center gap-2 text-4xl md:test-5xl font-semibold"
              >
                <Activity className="h-6 w-6 accent-text" /> {countriesValue}
                <span className="text-lg md:text-xl align-super">+</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                pays couverts (lancement France)
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-3xl md:text-4xl font-semibold">
                <BarChart3 className="h-6 w-6 accent-text" /> 14M
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                ordres exécutés (2024)
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-3xl md:text-4xl font-semibold">
                <TrendingUp className="h-6 w-6 accent-text" /> 1&nbsp;Md€
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                volume de transactions (2024)
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 text-2xl md:text-3xl font-semibold">
                <Award className="h-6 w-6 accent-text" /> Best European
                Technology Awards
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Lauréat 2024</p>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* FAQ — sans constellations */}
      <Section id="faq" title="Questions fréquentes" kicker="FAQ">
        <Accordion>
          <AccordionItem>
            <AccordionTrigger>
              La formation Skool est-elle pour débutants ?
            </AccordionTrigger>
            <AccordionContent>
              Oui, la feuille de route part des bases et t’amène jusqu’à
              l’exécution.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem>
            <AccordionTrigger>
              Le Software IA fait-il tout à ma place ?
            </AccordionTrigger>
            <AccordionContent>
              Non. Tu gardes le contrôle. L’IA assiste ta décision et automatise
              le répétitif.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem>
            <AccordionTrigger>
              Puis-je passer du mensuel à l’annuel ?
            </AccordionTrigger>
            <AccordionContent>Oui, à tout moment.</AccordionContent>
          </AccordionItem>
          <AccordionItem>
            <AccordionTrigger>Comment recevoir l’ebook ?</AccordionTrigger>
            <AccordionContent>
              Utilise le formulaire e-mail (recommandé) ou le lien d’accès
              direct.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </Section>

      {/* Footer */}
      <footer className="border-t border-subtle py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-4 md:flex-row">
          <div className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} La Brèche — Tous droits réservés.
          </div>
          <div className="flex items-center gap-4 text-sm">
            <a href="#about" className="hover:opacity-80">
              À propos
            </a>
            <a href="#services" className="hover:opacity-80">
              Services
            </a>
            <a href="#pourquoi-nous" className="hover:opacity-80">
              Pourquoi nous
            </a>
            <a href="#faq" className="hover:opacity-80">
              FAQ
            </a>
            <button onClick={openLegalPage} className="hover:opacity-80">
              Mentions légales
            </button>
          </div>
        </div>
      </footer>

      <CookieBanner />
    </div>
  );
}

/* ================== MINI ROUTER ================== */
export default function App() {
  const [route, setRoute] = useState(window.location.hash || "#/");
  useEffect(() => {
    const onHash = () => setRoute(window.location.hash || "#/");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  const goPreSale = () => {
    window.location.hash = "#/prevente";
    window.scrollTo(0, 0);
  };
  const goHome = () => {
    window.location.hash = "#/";
    window.scrollTo(0, 0);
  };

  if (route.startsWith("#/prevente")) {
    return (
      <PreSalePage
        onBack={goHome}
        PREV_TARGET={"2025-09-30T23:59:59"}
        FORM_ID_PRE={"3e471948-7877-11f0-b0cb-3bc085a6eaa0"}
      />
    );
  }
  return <SiteLaBreche goPreSale={goPreSale} />;
}
